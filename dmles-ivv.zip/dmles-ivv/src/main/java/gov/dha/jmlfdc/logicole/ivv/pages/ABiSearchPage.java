/*
 * POM: Abi Search Page
 * 
 */

package gov.dha.jmlfdc.logicole.ivv.pages;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import gov.dha.jmlfdc.logicole.ivv.utils.BasePage;

public class ABiSearchPage extends BasePage {

	private static Logger log = Logger.getLogger(ABiSearchPage.class.getName());
	private WebElement firstPageEle = null, prePageEle = null, nextPageEle = null, lastPageEle = null;
	JavascriptExecutor js = (JavascriptExecutor) driver;
	private long start, end;
	WebDriverWait wait = new WebDriverWait(driver, 60);

	/***************** Web Object Element ********************/
	private String searchInputEle = "searchInput";
	private String sidePanelEle = "toggleLeftSidePanel";
	private String productLineEle = "Product LineCategoryPanel";
	private String productCategoryEle = "Product CategoryCategoryPanel";
	private String productTypeEle = "Product TypeCategoryPanel";
	private String searchWithinResultEle = "searchWithinResultsInput";
	private String resultRowsEle = "#abiSearchDiv div[class^='ui-grid-row']";
	private String leftSidePanelResultEle = "//*[@id='abiLeftSidePanel']/div/div[2]/div/div/div/selected-facet-options-breadbox/div";
	/**************************** END **********************************/

	/***************** Expected String Text ********************/
	private String productLineTxt = "Product Line";
	private String productCategoryTxt = "Product Category";
	private String productTypeTxt = "Product Type";
	private int searchResult1 = 0, searchResult2 = 0, searchResult3 = 0;
	private String pageFirstButtonTxt = "Page to first";
	private String pageBackButtonTxt = "Page back";
	private String pageForwardButtonTxt = "Page forward";
	private String pageLastButtonTxt = "Page to last";
	private String firstPageSelectionTxt = "first-bar";
	private String prevousPageSelectionTxt = "first-triangle prev-triangle";
	private String nextPageSelectionTxt = "last-triangle next-triangle";
	private String lastPageSelectionTxt = "last-triangle";

	/**************************** END **********************************/

	/**
	 * Method Name : <b>inputABiSearchText</b> <br>
	 * Description : This method will inputer text for ABi Search.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void inputABiSearchText(String input) {
		log.info(String.format("inputABiSearchText(%s)", input));

		writeText(By.id(searchInputEle), input);
		delayFor(2);
		String result = readText(By.xpath("//*[@id='abiSearchDiv']/div[2]/div/div/div/span"));
		searchResult1 = Integer.parseInt(result.substring(0, result.indexOf("item")).trim());

		List<WebElement> buttons = driver.findElements(By.tagName("button"));
		for (int i = 55; i < buttons.size(); i++) {
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageFirstButtonTxt)) {
				firstPageEle = buttons.get(i);
				buttonDisabled(firstPageEle);
			}
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageBackButtonTxt)) {
				prePageEle = buttons.get(i);
				buttonDisabled(prePageEle);
			}
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageForwardButtonTxt)) {
				nextPageEle = buttons.get(i);
				buttonEnabled(nextPageEle);
			}
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageLastButtonTxt)) {
				lastPageEle = buttons.get(i);
				buttonEnabled(lastPageEle);
			}
		}
	}

	/**
	 * Method Name : <b>expandSidePanel</b> <br>
	 * Description : This method will expand side panel.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void expandSidePanel() {
		log.info(String.format("expandSidePanel()"));

		start = System.currentTimeMillis();
		click(By.id(sidePanelEle));
		verifyText(By.id(productLineEle), productLineTxt);
		verifyText(By.id(productCategoryEle), productCategoryTxt);
		verifyText(By.id(productTypeEle), productTypeTxt);
		end = System.currentTimeMillis();
		log.info("Time calcuate in milliseconds to click side panel: " + (end - start - 5000));

	}

	/**
	 * Method Name : <b>inputABiSearchText</b> <br>
	 * Description : This method will inputer text for ABi Search.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void inputSearchWithinResult(String input) {
		log.info(String.format("inputSearchWithinResult(%s)", input));

		writeText(By.id(searchWithinResultEle), input);
		delayFor(2);
		String result = readText(By.xpath("//*[@id='abiSearchDiv']/div[2]/div/div/div/span"));
		searchResult2 = Integer.parseInt(result.substring(0, result.indexOf("item")).trim());
	}

	/**
	 * Method Name : <b>selectProductType</b> <br>
	 * Description : This method will select type of the product.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void selectProductType(String inputType) {
		log.info(String.format("selectProductType(%s)", inputType));

		List<WebElement> elements = driver.findElements(By.xpath("//span"));
		for (int i = 0; i < elements.size(); i++) {
			try {
				if (elements.get(i).getText().equalsIgnoreCase(inputType)) {
					elements.get(i).click();
				}
			} catch (Exception e) {
			}
		}

		delayFor(1);
		String expProductLineResult = "Product Line: " + inputType;
		List<WebElement> elementsResults = driver.findElements(By.xpath(leftSidePanelResultEle));
		for (int i = 0; i < elementsResults.size(); i++) {
			try {
				if (elementsResults.get(i).getText().equals(expProductLineResult)) {
					assertTrue(true);
					break;
				}
			} catch (Exception e) {
			}
		}

		List<WebElement> buttons = driver.findElements(By.tagName("button"));
		for (int i = 55; i < buttons.size(); i++) {
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageFirstButtonTxt)) {
				firstPageEle = buttons.get(i);
				buttonDisabled(firstPageEle);
			}
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageBackButtonTxt)) {
				prePageEle = buttons.get(i);
				buttonDisabled(prePageEle);
			}
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageForwardButtonTxt)) {
				nextPageEle = buttons.get(i);
				buttonEnabled(nextPageEle);
			}
			if (buttons.get(i).getAttribute("title").equalsIgnoreCase(pageLastButtonTxt)) {
				lastPageEle = buttons.get(i);
				buttonEnabled(lastPageEle);
			}
		}

		delayFor(3);
		String result = readText(By.xpath("//*[@id='abiSearchDiv']/div[2]/div/div/div/span"));
		searchResult3 = Integer.parseInt(result.substring(0, result.indexOf("item")).trim());
	}

	/**
	 * Method Name : <b>pageActions</b> <br>
	 * Description : This method will navigate to page and verify the page buttons.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void pageActions(PageSelections pageSelections) {
		log.info(String.format("Page Navigation: " + getPageSelections(pageSelections)));

		List<WebElement> pageActButtons = null;
		pageActButtons = driver.findElements(By.tagName("div"));
		for (int i = 1080; i < pageActButtons.size(); i++) {
			if (pageActButtons.get(i).getAttribute("class").equalsIgnoreCase(getPageSelections(pageSelections))) {
				js.executeScript("arguments[0].scrollIntoView(true)", pageActButtons.get(i));
				pageActButtons.get(i).click();
				if (getPageSelections(pageSelections).equalsIgnoreCase(firstPageSelectionTxt)) {
					buttonDisabled(firstPageEle);
					buttonDisabled(prePageEle);
					buttonEnabled(nextPageEle);
					buttonEnabled(lastPageEle);
					break;
				}
				if (getPageSelections(pageSelections).equalsIgnoreCase(lastPageSelectionTxt)) {
					buttonEnabled(firstPageEle);
					buttonEnabled(prePageEle);
					buttonDisabled(nextPageEle);
					buttonDisabled(lastPageEle);
					prePageEle.click();
					break;
				}
				if (getPageSelections(pageSelections).equalsIgnoreCase(prevousPageSelectionTxt)) {
					if (!firstPageEle.isEnabled()) {
						buttonDisabled(firstPageEle);
						buttonDisabled(prePageEle);
						buttonEnabled(nextPageEle);
						buttonEnabled(lastPageEle);
						break;
					} else {
						buttonEnabled(firstPageEle);
						buttonEnabled(prePageEle);
						buttonEnabled(nextPageEle);
						buttonEnabled(lastPageEle);
						break;
					}
				}
				if (getPageSelections(pageSelections).equalsIgnoreCase(nextPageSelectionTxt)) {
					if (!lastPageEle.isEnabled()) {
						buttonEnabled(firstPageEle);
						buttonEnabled(prePageEle);
						buttonDisabled(nextPageEle);
						buttonDisabled(lastPageEle);
						prePageEle.click();
						break;
					} else {
						buttonEnabled(firstPageEle);
						buttonEnabled(prePageEle);
						buttonEnabled(nextPageEle);
						buttonEnabled(lastPageEle);
						break;
					}
				}
			}
		}
	}

	/**
	 * Method Name : <b>pageNumberSelection</b> <br>
	 * Description : This method will navigate to specify page.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void pageNumberSelection(String pageNumber) {
		log.info(String.format("Navigate to Page Number: " + pageNumber));

		delayFor(2);
		int currentPageNum = 0, currentItemPerPage = 0, totalNumbers = 0;
		List<WebElement> pageNumSelection = driver.findElements(By.tagName("input"));
		for (int i = 30; i < pageNumSelection.size(); i++) {
			try {
				if (pageNumSelection.get(i).getAttribute("title").equalsIgnoreCase("Selected page")) {
					try {
						js.executeScript("arguments[0].scrollIntoView(true)", pageNumSelection.get(i));
						pageNumSelection.get(i).click();
						pageNumSelection.get(i).sendKeys(Keys.chord(Keys.CONTROL, "a"));
						pageNumSelection.get(i).sendKeys(pageNumber);
						currentPageNum = Integer.parseInt(pageNumSelection.get(i).getAttribute("value"));
					} catch (Exception e) {
					}
				}
			} catch (Exception e) {
			}
		}
		List<WebElement> items = driver.findElements(By.tagName("select"));
		for (int i = 0; i < items.size(); i++) {
			Select dropdown = new Select(items.get(i));
			currentItemPerPage = Integer.parseInt(dropdown.getFirstSelectedOption().getText());
		}
		List<WebElement> itemsNum = driver.findElements(By.tagName("span"));
		String test, testConv;
		for (int i = 600; i < itemsNum.size(); i++) {

			try {
				if (itemsNum.get(i).getAttribute("ng-show").contains("totalItems")) {
					test = itemsNum.get(i).getText();
					testConv = test.substring(test.indexOf("-") + 1, test.indexOf("of"));
					totalNumbers = Integer.parseInt(testConv.trim());
				}
			} catch (Exception e) {
			}
		}
		assertTrue(totalNumbers == currentPageNum * currentItemPerPage);
	}

	/**
	 * Method Name : <b>pageNumberItems</b> <br>
	 * Description : This method will display numbers of items.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void pageNumberItems(String itemsPerPage) {
		log.info(String.format("Display number of items per page: " + itemsPerPage));

		delayFor(2);
		List<WebElement> items = driver.findElements(By.tagName("select"));
		for (int i = 0; i < items.size(); i++) {
			Select dropdown = new Select(items.get(i));
			dropdown.selectByVisibleText(itemsPerPage);
		}

		List<WebElement> itemResults = driver.findElements(By.tagName("div"));
		int count = 0;
		for (int i = 480; i < itemResults.size(); i++) {
			try {
				if (itemResults.get(i).getAttribute("ng-repeat").contains("(rowRenderIndex")) {
					count++;
				}
			} catch (Exception e) {
			}
		}
		List<WebElement> itemsNum = driver.findElements(By.tagName("span"));
		String itemsPerPageTest = null, test1;
		for (int i = 600; i < itemsNum.size(); i++) {
			try {
				if (itemsNum.get(i).getAttribute("ng-if").contains("visibleRowCache")) {
					js.executeScript("arguments[0].scrollIntoView(true)", itemsNum.get(i));
					test1 = itemsNum.get(i).getText();
					itemsPerPageTest = test1.substring(test1.indexOf(":") + 1, test1.indexOf(")"));
				}
			} catch (Exception e) {
			}
		}

		assertTrue(Integer.parseInt(itemsPerPage.replaceAll("\\s+", "")) == count);
		assertTrue(Integer.parseInt(itemsPerPage.replaceAll("\\s+", "")) == Integer.parseInt(itemsPerPageTest.replaceAll("\\s+", "")));
	}

	/**
	 * Method Name : <b>verifyABiSearchResult</b> <br>
	 * Description : This method will test and verify ABi Search.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void verifyABiSearchResult() {
		log.info(String.format("verifyABiSearchResult()"));

		delayFor(2);
		List<WebElement> elements = driver.findElements(By.tagName("button"));
		int count = 0;
		for (int i = 0; i < elements.size(); i++) {
			if (elements.get(i).getAttribute("id").contains("goToDetailsButtonLink")) {
				count = count + 1;
			}
		}
		assertTrue(count > 0);
	}

	/**
	 * Method Name : <b>verifySearchResults</b> <br>
	 * Description : This method will verify search results.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void verifySearchResults() {
		log.info(String.format("verifySearchResults()"));

		try {
			if (searchResult1 >= searchResult2 && searchResult2 >= searchResult3);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public enum PageSelections {
		First_Page, Prevous_Page, Next_Page, Last_Page

	}

	private String getPageSelections(PageSelections pageSelections) {

		String tempPageSelection = "";
		if (pageSelections == PageSelections.First_Page) {
			tempPageSelection = firstPageSelectionTxt;
		} else if (pageSelections == PageSelections.Prevous_Page) {
			tempPageSelection = prevousPageSelectionTxt;
		} else if (pageSelections == PageSelections.Next_Page) {
			tempPageSelection = nextPageSelectionTxt;
		} else if (pageSelections == PageSelections.Last_Page) {
			tempPageSelection = lastPageSelectionTxt;
		}

		return tempPageSelection;
	}
	
	/**
	 * Description : This method will click on Product Identifier button to view product details in searched results table
	 * Usage : viewProductDetails("00382903096046");
	 * @throws InterruptedException 
	 * Author: Hannan Chowdhury
	 */
	public void viewProductDetails(String productIdentifier) throws InterruptedException
	{
		WebElement rowObject = getResultRowObject(productIdentifier);
		Actions action = new Actions(driver);
		WebElement button_object = rowObject.findElement(By.cssSelector("button[id^='goToDetailsButtonLink']"));
		action.click(button_object).perform();
		String xpath = "//div[@id= 'abiSearchDiv']//small[normalize-space(text())='" + productIdentifier + "']";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	}
	
	/**
	 * Description : This method will click on check box to compare product in searched results table
	 * Usage : checkProductToCompare("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	public void checkProductToCompare(String productIdentifier)
	{
		WebElement rowObject = getResultRowObject(productIdentifier);
		WebElement row = rowObject.findElement(By.cssSelector("input[type='checkbox'][title^='Select to compare']"));
		Actions action = new Actions(driver);
		action.moveToElement(row).click().build().perform();
	}
	
	
	/**
	 * Description : This method will click on view related site records button to view product related site records in searched results table
	 * Usage : viewProductRelatedSiteRecords("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	public void viewProductRelatedSiteRecords(String productIdentifier)
	{
		WebElement rowObject = getResultRowObject(productIdentifier);
		Actions action = new Actions(driver);
		WebElement button_object = rowObject.findElement(By.cssSelector("button[id^='viewRelatedSiteRecordsButtonLink']"));
		action.moveToElement(button_object).click().perform();
		delayFor(5);
	}
	
	/**
	 * Description : This method will click on view related products button to view related products of product in searched results table
	 * Usage : viewRelatedProducts("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	public void viewRelatedProducts(String productIdentifier)
	{
		WebElement rowObject = getResultRowObject(productIdentifier);
		Actions action = new Actions(driver);
		WebElement button_object = rowObject.findElement(By.cssSelector("button[id^='viewRelatedProductsButtonLink']"));
		action.moveToElement(button_object).click().perform();
	}
	
	/**
	 * Description : This method will return Abi search result row object by product identifier value
	 * Usage : getResultRowObject("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	private WebElement getResultRowObject(String productIdentifier) 
	{
		int rowIndex = -1;
		WebElement rowObject = null;
		List<WebElement> elements = driver.findElements(By.cssSelector("button[id^='goToDetailsButtonLink']"));
		for (int row = 0; row < elements.size(); row++) 
		{
			String actualProductIdentifier = elements.get(row).getText();
			if (productIdentifier.equals(actualProductIdentifier)) 
			{
				rowIndex = row;
				break;
			}
		}
		if (rowIndex != -1)
		{
			List<WebElement> rowElements = driver.findElements(By.cssSelector(resultRowsEle));
			rowObject = rowElements.get(rowIndex);
		}
		else
		{
			String msg = String.format("[%s] Product Identifier not exist in Abi search result", productIdentifier); 
			throw new RuntimeException(msg);
		}
		return rowObject;
	}
	
	/**
	 * Description : This method will verify Abi search summary result columns
	 * Usage : getResultRowObject("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	public void verifySearchPageColumnName(List<String> expectedColumnList)
	{
		List<WebElement> columnNameElements = driver.findElements(By.cssSelector("#abiSearchDiv div[role='columnheader']"));	
		List<String> actualColumnsList = new ArrayList<String>();
		for(int index = 0; index<columnNameElements.size(); index++)
		{
			String columnText = columnNameElements.get(index).getText().trim();
			if(columnText!="")
			{
				actualColumnsList.add(columnText);	
			}
		}
		System.out.println("Actual Search Page Columns Name : " + actualColumnsList);
		System.out.println("Expected Search Page Columns Name : " + expectedColumnList);
		assertTrue(expectedColumnList.equals(actualColumnsList));
	}
	
	/**
	 * Description : This method will click on Back button in the Product Details page
	 * Usage : getResultRowObject("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	
	public void goBackFromProductDetailsPage()
	{
		WebElement BackButton = driver.findElement(By.id("goBackFromProductDetailsButton"));
		BackButton.click();
	}
	
	/**
	 * Description : This method will click on Back button in the Related Site Records page
	 * Usage : getResultRowObject("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	public void goBackFromRelatedSiteRecord()
	{
		WebElement BackButton = driver.findElement(By.id("goBackFromProductsRelatedSiteRecordsButton"));
		js.executeScript("arguments[0].scrollIntoView(true)", BackButton);
		BackButton.click();
	}
	
	/**
	 * Description : This method will verify the contents in the Product Details page
	 * Usage : getResultRowObject("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	public void verifyProductDetailLabels(String[] expectedLabels)
	{	
		List<WebElement> LabelElements = driver.findElements(By.cssSelector("#abiSearchDiv dl[ng-if*='abiProduct']>dt")); 
		 ArrayList<String> actualColumnsList = new ArrayList<String>();
		 for(int index = 0; index<LabelElements.size(); index++)
		 {
		  if (LabelElements.get(index).isDisplayed())
		  {
			  String columnText = js.executeScript("return arguments[0].innerText.trim()", LabelElements.get(index)).toString();
			  if(columnText!="")
			  {
				  actualColumnsList.add(columnText); 
			  }
		  }
		 }
		 ArrayList<String> expectedLabelList = new ArrayList<String>(Arrays.asList(expectedLabels));
		 System.out.println("Actual Search Page Columns Name : " + actualColumnsList);
		 System.out.println("Expected Search Page Columns Name : " + expectedLabelList);
		 assertTrue(expectedLabelList.equals(actualColumnsList));
	}
		 
    public void verifyproductIdentifierInProductDetailsPage(String expectedValue)
    {
    	WebElement Element = driver.findElement(By.cssSelector("#abiSearchDiv small"));
    	String actualValue = Element.getText().trim();
    	assertTrue(expectedValue.equals(actualValue));
    }
		 
    public void expandProductDetailLabel()
    {
    	WebElement expandIcon = driver.findElement(By.cssSelector("#abiSearchDiv dl[ng-if*='abiProduct'] .fa-plus"));
    	expandIcon.click();
    	delayFor(2);
    }
	
	public void clearProductCatSelections()
	{
		WebElement ClearButton = driver.findElement(By.cssSelector("button[id='Product CategoryClearAllSelectionsButton']"));
		ClearButton.click();	
	}
	
	public void clearProductLineSelection()
	{
		WebElement ClearButton = driver.findElement(By.cssSelector("button[id='Product LineClearAllSelectionsButton']"));
		ClearButton.click();
	}
	
	public void clearProductTypeSelections()
	{
		WebElement ClearButton = driver.findElement(By.cssSelector("button[id='Product TypeClearAllSelectionsButton']"));
		ClearButton.click();	
	}
	
	public void checkAbiSummaryPageEmpty()
	{
		WebElement ResultSummary = driver.findElement(By.cssSelector("#abiSearchDiv div[class='row col-sm-12']>div"));
		String ActualResultSummary = ResultSummary.getText().trim();
		assertTrue(ActualResultSummary.equals(""));		
	}
	
	/**
	 * Description : This method will select ABi Search page column Dropdown menu
	 * Usage : getResultRowObject("00382903096046");
	 * Author: Hannan Chowdhury
	 */
	public void selectSearchPageResultColumnDropdownMenu(String ColumnName, String DropdownMenu)
	{
		List<WebElement> columnNameElements = driver.findElements(By.cssSelector("#abiSearchDiv div[role='columnheader']"));	
		for(int index = 0; index<columnNameElements.size(); index++)
		{
			String columnText = columnNameElements.get(index).getText().trim();
			if(columnText==ColumnName)
			{
				WebElement Column = columnNameElements.get(index).findElement(By.cssSelector("i.ui-grid-icon-angle-down"));
				Column.click();
				break;
			}
		}
		List<WebElement> DropdownElements = driver.findElements(By.cssSelector("div[ng-show='showMid'] button"));	
		for(int index = 0; index<columnNameElements.size(); index++)
		{
			String menuText = DropdownElements.get(index).getText().trim();
			if(menuText==DropdownMenu)
			{
				WebElement Menu = columnNameElements.get(index);
				Menu.click();
				break;
			}
		}
	}
	
	public void SelectCategoryOption(String CategoryName, String Option)
	{	
	 WebElement CategoryParentPanelObject = getCategoryParentPanel(CategoryName);
	 String  XpathValue = String.format("//span[normalize-space()='%s']", Option);
	 WebElement OptionObject = CategoryParentPanelObject.findElement(By.xpath(XpathValue));
	 js.executeScript("arguments[0].scrollIntoViewIfNeeded()", OptionObject);
	 delayFor(1);
	 OptionObject.click();
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#abiSearchDiv .fa-info-circle")));
	}

	public void ClearCategorySelections(String CategoryName)
	{
	 WebElement CategoryParentPanelObject = getCategoryParentPanel(CategoryName);
	 WebElement ClearButton = CategoryParentPanelObject.findElement(By.cssSelector("button[id*='ClearAllSelectionsButton']"));
	 ClearButton.click();
	 delayFor(10);
	}

	public void CheckSummaryResultsCleared()
	{
	 WebElement ResultSummary = driver.findElement(By.cssSelector("#abiSearchDiv div[class='row col-sm-12']>div"));
	 String ActualResultSummary = ResultSummary.getText().trim();
	 assertTrue(ActualResultSummary.equals(""));  
	}

	public void clearAll()
	{
	 WebElement ClearButton = driver.findElement(By.cssSelector("button[id='breadboxClearAllButton']"));
	 ClearButton.click();
	 delayFor(10);
	}

	public void checkSummaryResultColumns(String[] expectedColumn)
	{
	 List<WebElement> columnNameElements = driver.findElements(By.cssSelector("#abiSearchDiv div[role='columnheader']")); 
	 ArrayList<String> actualColumnsList = new ArrayList<String>();
	 for(int index = 0; index<columnNameElements.size(); index++)
	 {
	//  String columnText = columnNameElements.get(index).getText().trim();
	  String columnText = js.executeScript("return arguments[0].innerText.trim()", columnNameElements.get(index)).toString();
	  if(columnText!="")
	  {
	   actualColumnsList.add(columnText); 
	  }
	 }
	 ArrayList<String> expectedColumnList = new ArrayList<String>(Arrays.asList(expectedColumn));
	 System.out.println("Actual Search Page Columns Name : " + actualColumnsList);
	 System.out.println("Expected Search Page Columns Name : " + expectedColumnList);
	 assertTrue(expectedColumnList.equals(actualColumnsList));
	 
	}

	private WebElement getCategoryParentPanel(String CategoryName)
	{
	 List<WebElement> PanelHeadingObjects = driver.findElements(By.cssSelector("#abiLeftSidePanel .dmlesSearchPanelHeading"));
	 int PanelIndex = -1;
	 for(int index=0; index<PanelHeadingObjects.size(); index++)
	 {
	  String actualCategoryName = PanelHeadingObjects.get(index).getText().trim();
	  if(actualCategoryName.equals(CategoryName))
	  {
	   js.executeScript("arguments[0].scrollIntoViewIfNeeded()", PanelHeadingObjects.get(index));
	   delayFor(1);
	   PanelIndex = index;
	   break;
	  }
	 }
	 List<WebElement> PanelObjects = driver.findElements(By.cssSelector("#abiLeftSidePanel div.panel-default"));
	 WebElement CategoryParentPanelObject = PanelObjects.get(PanelIndex);
	 return CategoryParentPanelObject;
	}
	
	public void checkCategoryOptionsInAscendingOrder(String CategoryName)
	{
		ArrayList<String> optionsList = getCategoryOptions(CategoryName);
		assertTrue(isAscendingOrder(optionsList));
	}

	private ArrayList<String> getCategoryOptions(String CategoryName)
	{
		 WebElement CategoryParentPanelObject = getCategoryParentPanel(CategoryName);
		 ArrayList<String> optionsList = new ArrayList<String>();
		 List<WebElement> optionsObject = CategoryParentPanelObject.findElements(By.cssSelector("span.dmlesCategoryValue"));
		 for(int index=0; index<optionsObject.size(); index++)
		 {
			 String columnText = js.executeScript("return arguments[0].innerText.trim()", optionsObject.get(index)).toString();
			 optionsList.add(columnText);
		 }
		 return optionsList;
	}
	private boolean isAscendingOrder(ArrayList<String> listValues)
	{
		ArrayList<String> orderedList = new ArrayList<String>();
		orderedList.addAll(listValues);
		Collections.sort(listValues);
		return orderedList.equals(listValues);
	}
	
	public void SearchProduct(String Product)
	{
		WebElement SearchBox = driver.findElement(By.id("searchInput"));
		SearchBox.clear();
		SearchBox.sendKeys(Product);
		WebElement SearchButton = driver.findElement(By.id("searchButton"));
		SearchButton.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#abiSearchDiv .fa-info-circle")));
		delayFor(8);
	}
	
	public void ClickCompareProductViewButton(int rownumber)
	{
		String ViewButtonId = "compareButtonLink" + Integer.toString(rownumber);
		WebElement ViewButton = driver.findElement(By.id(ViewButtonId));
		ViewButton.click();
		delayFor(4);
	}
	
	public void checkProductIdentifierInProductComparePage(String[] expectedIdentifier)
	{
	 List<WebElement> IdentifierElements = driver.findElements(By.cssSelector("#abiSearchDiv table>tbody>tr:nth-child(4)>td")); 
	 ArrayList<String> actualIdentifierList = new ArrayList<String>();
	 for(int index = 0; index<IdentifierElements.size(); index++)
	 {
		 String IdentifierElementsText = IdentifierElements.get(index).getText().trim();  
		 actualIdentifierList.add(IdentifierElementsText); 
	 }
	 ArrayList<String> expectedIdentifierList = new ArrayList<String>(Arrays.asList(expectedIdentifier));
	 System.out.println("Actual Comparison Page Identifier : " + actualIdentifierList);
	 System.out.println("Expected Comparison Page Identifier : " + expectedIdentifierList);
	 assertTrue(expectedIdentifierList.equals(actualIdentifierList));
	}
	
	public void goBackFromProductComparisonPage()
	{
		WebElement BackButton = driver.findElement(By.id("goBackFromProductComparisonButton"));
		js.executeScript("arguments[0].scrollIntoView(true)", BackButton);
		BackButton.click();
		delayFor(4);	
	}

	public void CheckCompareProductCheckBoxUnchecked(String productIdentifier)
	{
		WebElement rowObject = getResultRowObject(productIdentifier);
		WebElement CheckBox = rowObject.findElement(By.cssSelector("input[type='checkbox'][title^='Select to compare']"));
		boolean CheckBoxStatus = CheckBox.isSelected();
		assertFalse(CheckBoxStatus);
	}
	
}