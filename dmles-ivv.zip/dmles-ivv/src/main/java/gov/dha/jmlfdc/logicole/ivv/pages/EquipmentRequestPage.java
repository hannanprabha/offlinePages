/*
 * POM: Equipment Request Page
 */
package gov.dha.jmlfdc.logicole.ivv.pages;

import static org.junit.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import gov.dha.jmlfdc.logicole.ivv.utils.BasePage;

public class EquipmentRequestPage extends BasePage {

	private static Logger log = Logger.getLogger(EquipmentRequestPage.class.getName());
	private List<String> species = new ArrayList<String>();
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	/***************** Web Object Element ********************/
	private String organizationEle = "changeAccess";
	private String createNewReqEle = "createNewRequestButton";
	private String myReqEle = "filterSubmittedByMeButton";
	private String myOrgEle = "filterSubmittedByMyOrgButton";
	private String requestTitleEle = "requestTitle";
	private String requestTypeEle = "requestTypes";
	private String requestReasonEle = "requestReasons";
	private String requestCriticalEle = "criticalCodes";
	private String requestMissionImpactEle = "missionImpact";
	private String requestExplannationEle = "requestDescription";
	private String requestDeliveryDateEle = "requestedDeliveryDate";
	private String requestDeliveryDateJustificationEle = "//*[@id='requestedDeliveryDateJustification']";
	private String customerNameEle = "customerName";
	private String customerReqFirstNameEle = "requesterNameFirst";
	private String customerReqLastNameEle = "requesterNameLast";
	private String customerReqPhoneEle = "requesterPhone";
	private String customerReqEmalEle = "requesterEmail";
	private String equipmentDescriptEle = "equipmentDescription";
	private String equipmentNomenclatureEle = "itemNomenclature";
	private String equipmentManufacturerEle = "manufacturer";
	private String equipmentModelEle = "modelNumber";
	private String equipmentUnitCostEle = "unitCost";
	private String equipmentQuantityEle = "quantity";
	private String equipmentAddEquipmentRequirementButtonEle = "addEquipmentRequirementButton";
	private String equipmentCategoriesEle = "categories";
	private String equipmentReqOptionsEle = "options";
	private String equipmentSpecificationEle = "specificationField0";
	private String equipmentCheckboxEle = "requiresOtherSystemsCheckBox";
	private String equipmentCheckboxTexEle = "requiresOtherSystems";
	private String sourceNameEle = "sourceName0";
	private String sourceCreditCardEle = "creditCard";
	private String sourcepocFirstNameEle = "pocFirstName0";
	private String sourcepocLastNameEle = "pocLastName0";
	private String sourcepocEmailEle = "pocEmail";
	private String sourcepocPhoneEle = "pocPhone1";
	private String sourceAdditionInfoEle = "//*[@id='source0']/div[1]/a";
	private String sourceContractNumberEle = "contract0";
	private String sourceContactExpDateEle ="contactExpDate0";
	private String sourceSupplierCatalogNumberEle = "supplierCatalogNumber0";
	private String sourcesupplierCatalogReferenceEle = "supplierCatalogReference0";
	private String sourceSupplierCatalogDateEle = "supplierCatalogDate0";
	private String sourceSupplierAddress1Ele = "supplierAddress10";
	private String sourceSupplierCityEle = "supplierCity0";
	private String sourceSupplierStateEle = "supplierState0";
	private String sourceSupplierZipEle = "supplierZip0";
	private String sourceSupplierCountryEle = "supplierCountry0";
	private String sourcepocAltPhoneEle = "pocPhone20";
	private String sourceurlEle = "url0";
	private String supplementaryItemsEle = "addCompAccSuppButton";
	private String supplementaryTypeEle = "itemType";
	private String supplementaryDescriptionEle = "itemDescription0";
	private String supplementaryItemNumberEle = "itemNumber0";
	private String supplementarycompAccSuppQuantityEle = "compAccSuppQuantity0";
	private String supplementarycompAccSuppUnitofPurchaseyEle = "compAccSuppUnitofPurchase0";
	private String supplementarycompAccSuppUnitofCostEle = "compAccSuppUnitofCost0";
	private String trainingEle = "addTrainingButton";
	private String trainingTraineesInputEle = "traineesInput0";
	private String trainingNumPeopleEle = "numPeopleInput0";
	private String trainingLocationEle = "locationInput0";
	private String trainingRegistrationCostEle = "registrationCostInput0";
	private String trainingTravelCheckboxEle = "registrationCostIncluded0";
	private String trainingTravelCostEle = "travelCostInput0";
	private String trainingPerDiemEle = "perDiemInput0";
	private String trainingDaysEle = "daysInput0";
	private String trainingCommentsEle = "trainingComments0";
	private String saveNewRequestEle = "//*[@id='saveNewRequest']";
	private String submitRequestEle = "submitRequest";
	private String deleteRequestEle = "deleteButton";
	
	/**************************** END **********************************/

	/***************** Expected String Text ********************/
	private String createNewReq = "Create a Request";
	private String myReq = "My Requests";
	private String myOrg = "My Organization's Requests";
	private String activeRequests = "Active Requests";
	private String historicalRequests = "Historical Requests";
	private String requestMissionImpact = randomName(40, "ALPHA");
	private String requestExplanation = randomName(40, "ALPHA");
	private String requestDeliveryDateJustification = randomName(40, "ALPHA");
	private String customerFirstName = "first" + randomName(5, "ALPHA");
	private String customerLastName = "last" + randomName(5, "ALPHA");
	private String customerPhone = randomName(10, "NUM");
	private String equipmentDescript = randomName(50, "ALPHA_NUM");
	private String equipmentSpecification = randomName(30, "ALPHA_NUM");
	private String equipmentCheckboxTex = randomName(40, "ALPHA");
	private String sourcepocFirstName = "first" + randomName(10, "ALPHA");
	private String sourcepocLastName = "first" + randomName(10, "ALPHA");
	private String sourcepocEmail = randomName(10, "ALPHA") + "@mail.mil";
	private String sourcepocPhone = randomName(10, "NUM");	
	private String sourceSupplierAddress1 = randomName(30, "ALPHA_NUM");
	private String sourceSupplierCity = randomName(5, "ALPHA");
	private String sourceSupplierState = randomName(2, "ALPHA");
	private String sourceSupplierZip = randomName(5, "NUM");
	private String sourceSupplierCountry = randomName(5, "ALPHA");
	private String sourcepocAltPhone = randomName(10, "NUM");
	private String sourceurl = randomName(15, "ALPHA_NUM");
	private String supplementaryDescription = randomName(15, "ALPHA_NUM");
	private String trainingComments = randomName(20, "ALPHA_NUM");
	/**************************** END **********************************/

	/**
	 * Method Name : <b>verifyEquipmentRequestButton</b> <br>
	 * Description : This method will test and verify Equipment Request Buttons.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void verifyEquipmentRequestButton() {
		log.info(String.format("verifyTabValue(%s)", createNewReq + myReq + myOrg));

		delayFor(2);
		verifyText(By.id(createNewReqEle), createNewReq);
		verifyText(By.id(myReqEle), myReq);
		verifyText(By.id(myOrgEle), myOrg);
	}

	/**
	 * Method Name : <b>createNewRequest</b> <br>
	 * Description : This method will click create a new Equipment Request.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void createNewRequest() {
		log.info(String.format("createNewRequest"));

		delayFor(2);
		click(By.id(createNewReqEle));
		delayFor(2);
		species.clear();
		List<WebElement> elements = driver.findElements(By.tagName("h4"));
		for (int i = 0; i < elements.size(); i++) {
			try {
				species.add(elements.get(i).getText());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		assertTrue(species.contains("Request Information"));
		assertTrue(species.contains("Customer Information"));
		assertTrue(species.contains("Equipment Information"));
		assertTrue(species.contains("Suggested Sources"));
		assertTrue(species.contains("Supplementary Items"));
		assertTrue(species.contains("Training"));
	}

	/**
	 * Method Name : <b>verifyEquipmentRequestTabTitles</b> <br>
	 * Description : This method will test and verify Equipment Request tab titles Search.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void verifyEquipmentRequestTabTitles() {
		log.info(String.format("verifyUserManagementTabTitles(%s)", activeRequests + historicalRequests));

		delayFor(2);
		species.clear();
		List<WebElement> elements = driver.findElements(By.tagName("span"));
		for (int i = 0; i < elements.size(); i++) {
			try {
				if (!elements.get(i).getText().isEmpty() && !elements.get(i).getText().equals(null)) {
					species.add(elements.get(i).getText());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		assertTrue(species.contains(activeRequests));
		assertTrue(species.contains(historicalRequests));
	}
	
	/**
	 * Method Name : <b>fillRequestInformation</b> <br>
	 * Description : This method will test and fill request information.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void fillRequestInformation(String title, String type, String reason, String critical, String date) {
		log.info(String.format("fillRequestInformation(%s)", title + type + reason + critical + date));

		delayFor(2);
		writeText(By.id(requestTitleEle), title);
		List<WebElement> itemsType = driver.findElements(By.id(requestTypeEle));
		for (int i = 0; i < itemsType.size(); i++) {
			Select dropdown = new Select(itemsType.get(i));
			dropdown.selectByVisibleText(type);
		}
		List<WebElement> itemsReason = driver.findElements(By.id(requestReasonEle));
		for (int i = 0; i < itemsReason.size(); i++) {
			Select dropdown = new Select(itemsReason.get(i));
			dropdown.selectByVisibleText(reason);
		}
		List<WebElement> itemsCritical = driver.findElements(By.id(requestCriticalEle));
		for (int i = 0; i < itemsCritical.size(); i++) {
			Select dropdown = new Select(itemsCritical.get(i));
			dropdown.selectByVisibleText(critical);
		}
		writeText(By.id(requestMissionImpactEle), requestMissionImpact);
		writeText(By.id(requestExplannationEle), requestExplanation);
		if(date!=null && !date.isEmpty()){
			writeText(By.id(requestDeliveryDateEle), date);
			delayFor(2);
			writeText(By.xpath(requestDeliveryDateJustificationEle), requestDeliveryDateJustification);
		}else{
			
		}
	}

	/**
	 * Method Name : <b>fillCustomerInformation</b> <br>
	 * Description : This method will test and fill Customer information.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void fillCustomerInformation(String customer, String email) {
		log.info(String.format("fillCustomerInformation(%s)", customer + email));

		delayFor(2);
		String org = readText(By.xpath("//*[@id='request']/div/form/ng-form[2]/div/div[2]/div/div[1]/div[1]/div/p"));
		String orgDefault = readText(By.id(organizationEle));
		assertTrue(org.equals(orgDefault));
		writeText(By.id(customerNameEle), customer);
		writeText(By.id(customerReqFirstNameEle), customerFirstName);
		writeText(By.id(customerReqLastNameEle), customerLastName);
		writeText(By.id(customerReqPhoneEle), customerPhone);
		writeText(By.id(customerReqEmalEle), email);
	}
	
	/**
	 * Method Name : <b>fillEquipmentInformation</b> <br>
	 * Description : This method will test and fill Equipment information.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void fillEquipmentInformation(String nomenclature, String manufacturer, String model, String unitCost, String quantity, String category, String options) {
		log.info(String.format("fillCustomerInformation(%s)", nomenclature + manufacturer + model + unitCost + quantity + category));

		delayFor(2);
		writeText(By.id(equipmentDescriptEle), equipmentDescript);
		writeText(By.id(equipmentNomenclatureEle), nomenclature);
		writeText(By.id(equipmentManufacturerEle), manufacturer);
		writeText(By.id(equipmentModelEle), model);
		writeText(By.id(equipmentUnitCostEle), unitCost);
		writeText(By.id(equipmentQuantityEle), quantity);
		js.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.id(equipmentAddEquipmentRequirementButtonEle)));
		click(By.id(equipmentAddEquipmentRequirementButtonEle));
		delayFor(2);
		List<WebElement> itemsCategory = driver.findElements(By.id(equipmentCategoriesEle));
		for (int i = 0; i < itemsCategory.size(); i++) {
			Select dropdown = new Select(itemsCategory.get(i));
			dropdown.selectByVisibleText(category);
		}
		List<WebElement> itemsRequirment = driver.findElements(By.id(equipmentReqOptionsEle));
		for (int i = 0; i < itemsRequirment.size(); i++) {
			Select dropdown = new Select(itemsRequirment.get(i));
			dropdown.selectByVisibleText(options);
		}
		writeText(By.id(equipmentSpecificationEle), equipmentSpecification);
		click(By.id(equipmentCheckboxEle));
		delayFor(1);
		writeText(By.id(equipmentCheckboxTexEle), equipmentCheckboxTex);
	}
	
	/**
	 * Method Name : <b>fillSuggestedSources</b> <br>
	 * Description : This method will test and fill Suggested Sources.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void fillSuggestedSources(String sourceName, String creditCardOption, String contractNumber, String contractExpDate, String supplierCatalogNumber,
			String supplierCatalogReference, String supplierCatalogDate) {
		log.info(String.format("fillSuggestedSources(%s)", sourceName + creditCardOption ));
		
		delayFor(2);
		writeText(By.id(sourceNameEle), sourceName);
		List<WebElement> itemsCreditCard = driver.findElements(By.id(sourceCreditCardEle));
		for (int i = 0; i < itemsCreditCard.size(); i++) {
			Select dropdown = new Select(itemsCreditCard.get(i));
			dropdown.selectByVisibleText(creditCardOption);
		}
		writeText(By.id(sourcepocFirstNameEle), sourcepocFirstName);
		writeText(By.id(sourcepocLastNameEle), sourcepocLastName);
		writeText(By.id(sourcepocEmailEle), sourcepocEmail);
		writeText(By.id(sourcepocPhoneEle), sourcepocPhone);
		click(By.xpath(sourceAdditionInfoEle));
		writeText(By.id(sourceContractNumberEle), contractNumber);
		writeText(By.id(sourceContactExpDateEle), contractExpDate);
		writeText(By.id(sourceSupplierCatalogNumberEle), supplierCatalogNumber);
		writeText(By.id(sourcesupplierCatalogReferenceEle), supplierCatalogReference);
		writeText(By.id(sourceSupplierCatalogDateEle), supplierCatalogDate);
		js.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.id(sourceurlEle)));
		writeText(By.id(sourceSupplierAddress1Ele), sourceSupplierAddress1);
		writeText(By.id(sourceSupplierCityEle), sourceSupplierCity);
		writeText(By.id(sourceSupplierStateEle), sourceSupplierState);
		writeText(By.id(sourceSupplierZipEle), sourceSupplierZip);
		writeText(By.id(sourceSupplierCountryEle), sourceSupplierCountry);
		writeText(By.id(sourcepocAltPhoneEle), sourcepocAltPhone);
		writeText(By.id(sourceurlEle), sourceurl);

	}
	
	/**
	 * Method Name : <b>fillSupplementaryItems</b> <br>
	 * Description : This method will test and fill Supplementary Items.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void fillSupplementaryItems(String itemType, String itemNumber, String quanity, String unit, String unitCost) {
		log.info(String.format("fillSupplementaryItems(%s)", itemType));
		
		delayFor(2);
		click(By.id(supplementaryItemsEle));
		List<WebElement> itemsType = driver.findElements(By.id(supplementaryTypeEle));
		for (int i = 0; i < itemsType.size(); i++) {
			Select dropdown = new Select(itemsType.get(i));
			dropdown.selectByVisibleText(itemType);
		}
		writeText(By.id(supplementaryDescriptionEle), supplementaryDescription);
		writeText(By.id(supplementaryItemNumberEle), itemNumber);
		writeText(By.id(supplementarycompAccSuppQuantityEle), quanity);
		writeText(By.id(supplementarycompAccSuppUnitofPurchaseyEle), unit);
		writeText(By.id(supplementarycompAccSuppUnitofCostEle), unitCost);

	}
	
	/**
	 * Method Name : <b>fillTraining</b> <br>
	 * Description : This method will test and fill Training.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void fillTraining(String traineesType, String numPeople, String location, String registrationCost, String travelCost, String diem, String days) {
		log.info(String.format("fillTraining(%s)", traineesType));
		
		delayFor(2);
		js.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.id(trainingEle)));
		click(By.id(trainingEle));
		js.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.id(trainingLocationEle)));
		List<WebElement> itemsTrainees = driver.findElements(By.id(trainingTraineesInputEle));
		for (int i = 0; i < itemsTrainees.size(); i++) {
			Select dropdown = new Select(itemsTrainees.get(i));
			dropdown.selectByVisibleText(traineesType);
		}
		writeText(By.id(trainingNumPeopleEle), numPeople);
		List<WebElement> itemsLocations = driver.findElements(By.id(trainingLocationEle));
		for (int i = 0; i < itemsLocations.size(); i++) {
			Select dropdown = new Select(itemsLocations.get(i));
			dropdown.selectByVisibleText(location);
		}
		writeText(By.id(trainingRegistrationCostEle), registrationCost);
		click(By.id(trainingTravelCheckboxEle));
		writeText(By.id(trainingTravelCostEle), travelCost);
		writeText(By.id(trainingPerDiemEle), diem);
		writeText(By.id(trainingDaysEle), days);
		writeText(By.id(trainingCommentsEle), trainingComments);

	}
	
	/**
	 * Method Name : <b>saveandSubmit</b> <br>
	 * Description : This method will test and save and submit request.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void saveandSubmit() {
		log.info(String.format("saveandSubmit()"));
		
		delayFor(2);
		try{
			driver.findElement((By.xpath("//*[@id='request']/div/form/ng-form[1]/div/div[1]/div/div[1]/h4"))).click();
		}catch (Exception e) {
		}
		js.executeScript("window.scrollBy(0,0)", "");
		delayFor(2);
		js.executeScript("window.scrollBy(0,-300)", "");
		click(By.xpath(saveNewRequestEle));
//		click(By.id(submitRequestEle));

	}
	
	/**
	 * Method Name : <b>deleteRequest</b> <br>
	 * Description : This method will test and delete request.</br>
	 * Author: Zhen Kuang	
	 * Date: 03/08/2019
	 * 
	 */
	public void deleteRequest() {
		log.info(String.format("deleteRequest()"));
		
		delayFor(2);
		click(By.id(deleteRequestEle));
		click(By.xpath("//*[@id='confirmButton']"));
	}
}
