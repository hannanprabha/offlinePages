/**
 * Test Type: Regression
 * Area: ABiSearch
 * Test Case Description: This test case will verify the column name in the ABi Search Summary Results
 * Profile: Abi Management
 * Organization: N/A
 * Author: Hannan Chowdhury 
 * Date: 03/22/2019
 *  
 */
package gov.dha.jmlfdc.logicole.ivv.regressiontestcases.ABiSearch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.List;
import java.util.ArrayList;
import gov.dha.jmlfdc.logicole.ivv.ScriptBase;
import gov.dha.jmlfdc.logicole.ivv.pages.HomePage.EnvironmentType;

public class SearchEquivalentProductsWithABi_13 extends ScriptBase{ 

/**************************** Test Data ****************************/
protected String userProfile = "Abi Management";
protected String expectedSummaryResultColumns[] = {
  "Compare Products", 
  "Long Item Description", 
  "Enterprise Product Identifier",
  "Manufacturer",
  "Manufacturer Catalog Number",
  "National Drug Code (NDC)",
  "Common Model",
  "Product Status",
  "Related Site Records",
  "Site Equipment",
  "Related Products",
  "Equivalent Products",
  "Preferred Product"
};

/**************************** END ****************************/

@BeforeClass
public static void setUp() {
 homepage.setUpEnv();
}

@Test
public void testChromeSelenium() throws InterruptedException {

 // Step 1 - 3 : Launch url and login to the logicole
 homepage.startAppliaction(EnvironmentType.test_env);
 homepage.selectUserProfile(userProfile);
 homepage.selectABiSearch();
 
//Step 4 : Click the Open/Close side panel
abisearchpage.expandSidePanel();
		 
// Step 5 : Select Pharmaceutical or another product line category on the list
abisearchpage.SelectCategoryOption("Product Line", "Pharmaceutical");
 // Step 5 : Expected Result - The ABi Search screen displays the search summary results for the keyword entered in the text field.
abisearchpage.checkSummaryResultColumns(expectedSummaryResultColumns);
 
 // Step 7 : Scroll through the results and select an item then click on the View link in the Equivalent Products column to see the equivalent products for the item. 
abisearchpage.viewRelatedProducts("relatedProduct");

 
 // Step 8 : click back button goBackFromRelatedProductsButton
//abisearchpage.goBackFromRelatedProductsButton();
 
 // Step 9 : Repeat step 4-8 with different item
 
 
 // Step 4-6: logout and verify the output message
 homepage.logout();
}

@AfterClass
public static void cleanUp() {
//  homepage.cleanUpEnv();

}
 
}