/**
 * Test Type: Regression
 * Area: Equipment Request
 * Test Case Description: This test case will test and verify create new equipment in Site Level
 * Profile: Site Equipment Custodian
 * Organization: Winn Army Community Hospital
 * Author: Zhen Kuang	
 * Date: 03/08/2019
 *  
 */
package gov.dha.jmlfdc.logicole.ivv.regressiontestcases.EquipmentRequest;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import gov.dha.jmlfdc.logicole.ivv.ScriptBase;
import gov.dha.jmlfdc.logicole.ivv.pages.HomePage.EnvironmentType;

public class SiteLevelCreateNewEquipmentRequestRegression_01 extends ScriptBase{
	
	/**************************** Test Data ****************************/
	protected String userProfile = "Site Equipment Custodian";
	protected String organization = "Winn Army Community Hospital";
	protected String requestTitle = "Automation Test Equipment Request";
	protected String requestType = "New Requirement";
	protected String requestReason = "Increased Workload";
	protected String requestCritical = "1 - High Risk - Life or Death, Mission Essential";
	protected String requestDeliveryDate = "12/22/2020";
	protected String customerName = "Y06MMK";
	protected String customerEmail = "zhen.x.kuang.ctr@mail.mil";
	protected String equipmentNomenclature = "Acrylic Curing Unit, Dental"; 
	protected String equipmentManufacturer = "308 Systems Inc"; 
	protected String equipmentModel = "12345"; 
	protected String equipmentUnitCost = "2.00"; 
	protected String equipmentQuantity = "10";
	protected String equipmentCategory = "Structural";
	protected String equipmentRequirementOption = "Height";
	protected String sourceName = "automation source name";
	protected String sourceCreditCardAccepted = "Yes";
	protected String sourceContractNumber = "12345678";
	protected String sourceContractExpDate = "02/22/2020";
	protected String sourceSupplierCatalogNumber = "11961891";
	protected String sourceSupplierCatalogReference = "98498498";
	protected String sourceSupplierCatalogDate = "03/13/2020";
	protected String supplementaryItemType = "Accessory";
	protected String supplementaryItemNumber = "10";
	protected String supplementaryQuanity = "2";
	protected String supplementaryUnit = "5";
	protected String supplementaryUnitCost = "10.00";
	protected String trainingTraineesType = "Operator";
	protected String trainingNumPeople = "10";
	protected String trainingLocation = "Off-site";
	protected String trainingRegistrationCost = "50";
	protected String trainingTravelCost = "20.00";
	protected String trainingDiem = "4.00";
	protected String trainingDays = "10";
	
	/**************************** END ****************************/
	
	@BeforeClass
	public static void setUp() {
		homepage.setUpEnv();
	}

	@Test
	public void testChromeSelenium() throws InterruptedException {
		
		// Step 1 -3: launch url and login to the logicole
		homepage.startAppliaction(EnvironmentType.test_env);
		
		homepage.selectUserProfile(userProfile);
		
		homepage.selectOrganization(organization);
		
		homepage.selectEquipmentRequest();
		
		equipmentrequestpage.verifyEquipmentRequestButton();
		
		equipmentrequestpage.verifyEquipmentRequestTabTitles();
		
		equipmentrequestpage.createNewRequest();
		
		equipmentrequestpage.fillRequestInformation(requestTitle, 
													requestType, 
													requestReason, 
													requestCritical,
													requestDeliveryDate);
		
		equipmentrequestpage.fillCustomerInformation(customerName,
													 customerEmail);
		
		equipmentrequestpage.fillEquipmentInformation(equipmentNomenclature, 
													  equipmentManufacturer, 
													  equipmentModel, 
													  equipmentUnitCost, 
													  equipmentQuantity,
													  equipmentCategory,
													  equipmentRequirementOption);
		
		equipmentrequestpage.fillSuggestedSources(sourceName, 
												  sourceCreditCardAccepted, 
												  sourceContractNumber, 
												  sourceContractExpDate,
												  sourceSupplierCatalogNumber,
												  sourceSupplierCatalogReference,
												  sourceSupplierCatalogDate);

		equipmentrequestpage.fillSupplementaryItems(supplementaryItemType, 
													supplementaryItemNumber, 
													supplementaryQuanity,
													supplementaryUnit,
													supplementaryUnitCost);
		
		equipmentrequestpage.fillTraining(trainingTraineesType,
										  trainingNumPeople, 
										  trainingLocation, 
										  trainingRegistrationCost,
										  trainingTravelCost,
										  trainingDiem,
										  trainingDays);

		equipmentrequestpage.saveandSubmit();
		
		equipmentrequestpage.deleteRequest();
		// Step 4-6: logout and verify the output message
		homepage.logout();
	}

	@AfterClass
	public static void cleanUp() {
		homepage.cleanUpEnv();
	
	}

}
