/**
 * Test Type: Regression
 * Area: ABiSearch
 * Test Case Description: This test case will verify the column name in the ABi Search Summary Results
 * Profile: Abi Management
 * Organization: N/A
 * Author: Hannan Chowdhury 
 * Date: 03/22/2019
 *  
 */
package gov.dha.jmlfdc.logicole.ivv.regressiontestcases.ABiSearch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.List;
import java.util.ArrayList;
import gov.dha.jmlfdc.logicole.ivv.ScriptBase;
import gov.dha.jmlfdc.logicole.ivv.pages.HomePage.EnvironmentType;

public class ABiSearchClearAllandClearSections_11 extends ScriptBase{ 

/**************************** Test Data ****************************/
protected String userProfile = "Abi Management";
protected String expectedSummaryResultColumns[] = {
  "Compare Products", 
  "Long Item Description", 
  "Enterprise Product Identifier",
  "Manufacturer",
  "Manufacturer Catalog Number",
  "National Drug Code (NDC)",
  "Common Model",
  "Product Status",
  "Related Site Records",
  "Site Equipment",
  "Related Products",
  "Equivalent Products",
  "Preferred Product"
};

/**************************** END ****************************/

@BeforeClass
public static void setUp() {
 homepage.setUpEnv();
}

@Test
public void testChromeSelenium() throws InterruptedException {

 // Step 1 - 3 : Launch url and login to the logicole
 homepage.startAppliaction(EnvironmentType.test_env);
 homepage.selectUserProfile(userProfile);
 homepage.selectABiSearch();
 
 // Step 4 : Click the Open/Close side panel
 abisearchpage.expandSidePanel();
 
 // Step 5 : In the Product Line section select a product line (such as Radiology).
 abisearchpage.SelectCategoryOption("Product Line", "Radiology");
 
 // Step 5 - Expected  : The ABi search summary results display
 abisearchpage.checkSummaryResultColumns(expectedSummaryResultColumns);
 
 // Step 7 : Click on the Clear Selections button in the Product Line section.
 abisearchpage.ClearCategorySelections("Product Line");
 
 // Step 7 - Expected : The ABi search summary results screen clears. No results will display.
 abisearchpage.CheckSummaryResultsCleared();
 
 // Step 8 : select anything from product category section
 
 abisearchpage.SelectCategoryOption("Product Category", "Apparel and Luggage and Personal Care Products");
 
//Step 8 - Expected  : The Product Type section displays the product type values in alphabetical order associated with the product category selected 
abisearchpage.checkCategoryOptionsInAscendingOrder("Product Type");
abisearchpage.checkSummaryResultColumns(expectedSummaryResultColumns);

//Step 9 : Click on the Clear Selections button in the Product Category section.
abisearchpage.ClearCategorySelections("Product Category");

//Step 9 - Expected : The ABi search summary results screen clears. No results will display.
abisearchpage.CheckSummaryResultsCleared();

 // Step 4-6: logout and verify the output message
 homepage.logout();
}

@AfterClass
public static void cleanUp() {
//  homepage.cleanUpEnv();

}
 
}