/**
 * Test Type: Regression
 * Area: ABiSearch
 * Test Case Description: This test case will verify the column name in the ABi Search Summary Results
 * Profile: Abi Management
 * Organization: N/A
 * Author: Hannan Chowdhury 
 * Date: 03/22/2019
 *  
 */
package gov.dha.jmlfdc.logicole.ivv.regressiontestcases.ABiSearch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.List;
import java.util.ArrayList;
import gov.dha.jmlfdc.logicole.ivv.ScriptBase;
import gov.dha.jmlfdc.logicole.ivv.pages.HomePage.EnvironmentType;

public class CompareProductsABiSearchSummaryResults_10 extends ScriptBase{ 

/**************************** Test Data ****************************/
protected String userProfile = "Abi Management";
protected String expectedSummaryResultColumns[] = {
  "Compare Products", 
  "Long Item Description", 
  "Enterprise Product Identifier",
  "Manufacturer",
  "Manufacturer Catalog Number",
  "National Drug Code (NDC)",
  "Common Model",
  "Product Status",
  "Related Site Records",
  "Site Equipment",
  "Related Products",
  "Equivalent Products",
  "Preferred Product"
};

/**************************** END ****************************/

@BeforeClass
public static void setUp() {
 homepage.setUpEnv();
}

@Test
public void testChromeSelenium() throws InterruptedException {

 // Step 1 - 3 : Launch url and login to the logicole
 homepage.startAppliaction(EnvironmentType.test_env);
 homepage.selectUserProfile(userProfile);
 homepage.selectABiSearch();
 
// Step 4 : Enter search criteria (Example: gloves) into the text field next to Keyboard  and click on the Search button.
 abisearchpage.SearchProduct("gloves");
 
 // Step 4 : Expected Result - The ABi Search screen displays the search summary results for the keyword entered in the text field.
 abisearchpage.checkSummaryResultColumns(expectedSummaryResultColumns);
 
 // Step 5 : Click on check box to compare Prod
 abisearchpage.checkProductToCompare("20680651550839");
 abisearchpage.checkProductToCompare("20680651416593");
 abisearchpage.checkProductToCompare("20680651416586");
 abisearchpage.ClickCompareProductViewButton(1);
 
 // Step 6 : verify prod id
 String expectedIdentifiers[] = {"20680651550839", "20680651416593", "20680651416586"};
 abisearchpage.checkProductIdentifierInProductComparePage(expectedIdentifiers);
 
 // Step 7 : click back button
 abisearchpage.goBackFromProductComparisonPage();
 
 // Step 8 : click on check box previously checked in compare products
 abisearchpage.checkProductToCompare("20680651550839");
 abisearchpage.checkProductToCompare("20680651416593");
 abisearchpage.checkProductToCompare("20680651416586");
 
 // Step 8: expected result- check boxes unchecked and view link is no longer exist
 
 // Step 9 : Repeat step 4-8 with different item
 
 abisearchpage.SearchProduct("aspirin");
 abisearchpage.checkSummaryResultColumns(expectedSummaryResultColumns);
 abisearchpage.checkProductToCompare("00904404073");
 abisearchpage.checkProductToCompare("00904770480");
 abisearchpage.checkProductToCompare("00536105301");
 abisearchpage.ClickCompareProductViewButton(2);
 String expectedIdentifiers1[] = {"00904404073", "00904770480", "00536105301"};
 abisearchpage.checkProductIdentifierInProductComparePage(expectedIdentifiers1);
 abisearchpage.goBackFromProductComparisonPage();
 abisearchpage.checkProductToCompare("00904404073");
 abisearchpage.checkProductToCompare("00904770480");
 abisearchpage.checkProductToCompare("00536105301");
 
 
 // Step 4-6: logout and verify the output message
 homepage.logout();
}

@AfterClass
public static void cleanUp() {
//  homepage.cleanUpEnv();

}
 
}