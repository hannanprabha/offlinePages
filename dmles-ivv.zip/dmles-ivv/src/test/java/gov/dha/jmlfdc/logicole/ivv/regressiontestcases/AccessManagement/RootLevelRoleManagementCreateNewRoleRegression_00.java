/**
 * Test Type: Regression
 * Area: Role Management
 * Test Case Description: This test case will test and verify create new role in ROOT Level
 * Profile: Root
 * Organization: N/A
 * Author: Zhen Kuang	
 * Date: 03/08/2019
 *  
 */

package gov.dha.jmlfdc.logicole.ivv.regressiontestcases.AccessManagement;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import gov.dha.jmlfdc.logicole.ivv.ScriptBase;
import gov.dha.jmlfdc.logicole.ivv.pages.HomePage.EnvironmentType;

public class RootLevelRoleManagementCreateNewRoleRegression_00 extends ScriptBase{ 
	
	/**************************** Test Data ****************************/
	protected String userProfile = "Root";
	protected String invalidProfileLookup = "qeq2eqwe";
	protected String emailAddress = "zhen.x.kuang.ctr@mail.mil";
	protected String profileNamge = "IVV automation root";
	protected String profileLeve = "Root";
	protected String organization = "DML-ES";
	protected String roleAccess1 = "Admin Manager";
	protected String roleAccess2 = "Manage Users";
	protected String roleAccess3 = "Read-only User Profile Management";
	protected String roleAccess4 = "ABi Management";
	protected String roleAccess5 = "ABi Search";

	/**************************** END ****************************/
	
	@BeforeClass
	public static void setUp() {
		homepage.setUpEnv();
	}

	@Test
	public void testChromeSelenium() throws InterruptedException {

		// Step 1 -3: launch url and login to the logicole
		homepage.startAppliaction(EnvironmentType.test_env);
		
		homepage.selectUserProfile(userProfile);
		
		homepage.selectUserProfileManagement();
		
		usermanagement.verifyButtonValue();
		
		usermanagement.verifyUserManagementTabTitles();
		
		usermanagement.createInvitation();
		
		usermanagement.verifyInvalidProfileLookup(invalidProfileLookup);
		
		usermanagement.verifyProfileLookup(emailAddress);
		
		usermanagement.filloutIdentificationInfo(profileNamge);
		
		usermanagement.selectAccessLevel(profileLeve, organization);
		
		usermanagement.selectRoleAccess(roleAccess1);
		
		usermanagement.selectRoleAccess(roleAccess2);
		
		usermanagement.selectRoleAccess(roleAccess3);
		
		usermanagement.selectRoleAccess(roleAccess4);
		
		usermanagement.selectRoleAccess(roleAccess5);
		
		usermanagement.invitationConfirmation();
		
		usermanagement.verifyCancelInvitation();
		
		homepage.selectDashboard();
		
		// Step 4-6: logout and verify the output message
		homepage.logout();
	}

	@AfterClass
	public static void cleanUp() {
		homepage.cleanUpEnv();
	
	}
		
}


