/**
 * Test Type: Regression
 * Area: ABiSearch
 * Test Case Description: This test case will test and verify the page button, page number, page selection
 * Profile: Abi Management
 * Organization: N/A
 * Author: Zhen Kuang	
 * Date: 03/08/2019
 *  
 */
package gov.dha.jmlfdc.logicole.ivv.regressiontestcases.ABiSearch;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import gov.dha.jmlfdc.logicole.ivv.ScriptBase;
import gov.dha.jmlfdc.logicole.ivv.pages.ABiSearchPage.PageSelections;
import gov.dha.jmlfdc.logicole.ivv.pages.HomePage.EnvironmentType;

public class ABiSearchPageSelectionRegression_00 extends ScriptBase{ 

	/**************************** Test Data ****************************/
	protected String userProfile = "Abi Management";
	protected String productType = "Dental";
	protected String pageNumber = "8";
	protected String itemPerPage = "50";

	/**************************** END ****************************/
	
	
	@BeforeClass
	public static void setUp() {
		homepage.setUpEnv();
	}

	@Test
	public void testChromeSelenium() throws InterruptedException {

		// Step 1 -3: launch url and login to the logicole
		homepage.startAppliaction(EnvironmentType.test_env);
		
		homepage.selectUserProfile(userProfile);
		
		homepage.selectABiSearch();
		
		abisearchpage.expandSidePanel();
		
		abisearchpage.selectProductType(productType);
		
		abisearchpage.pageActions(PageSelections.Next_Page);
		
		abisearchpage.pageActions(PageSelections.Next_Page);
		
		abisearchpage.pageActions(PageSelections.Prevous_Page);
		
		abisearchpage.pageActions(PageSelections.Last_Page);
		
		abisearchpage.pageActions(PageSelections.Next_Page);
		
		abisearchpage.pageActions(PageSelections.Prevous_Page);
		
		abisearchpage.pageActions(PageSelections.Next_Page);
		
		abisearchpage.pageActions(PageSelections.First_Page);
		
		abisearchpage.pageActions(PageSelections.Next_Page);
		
		abisearchpage.pageNumberSelection(pageNumber);
//		
		abisearchpage.pageNumberItems(itemPerPage);
		
		
		// Step 4-6: logout and verify the output message
		homepage.logout();
	}

	@AfterClass
	public static void cleanUp() {
		homepage.cleanUpEnv();
	
	}
		
}