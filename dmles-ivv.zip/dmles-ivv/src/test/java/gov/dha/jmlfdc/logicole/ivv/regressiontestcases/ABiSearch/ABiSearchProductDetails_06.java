/**
 * Test Type: Regression
 * Area: ABiSearch
 * Test Case Description: This test case will verify the column name in the ABi Search Summary Results
 * Profile: Abi Management
 * Organization: N/A
 * Author: Hannan Chowdhury 
 * Date: 03/22/2019
 *  10087453102649
 */
package gov.dha.jmlfdc.logicole.ivv.regressiontestcases.ABiSearch;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import gov.dha.jmlfdc.logicole.ivv.ScriptBase;
import gov.dha.jmlfdc.logicole.ivv.pages.HomePage.EnvironmentType;

public class ABiSearchProductDetails_06 extends ScriptBase
{ 
	/**************************** Test Data ****************************/
	protected String userProfile = "Abi Management";
	protected String productIdentifier = "00796762874361";
	protected String productIdentifier1 = "10087453102649";
	protected String expectedSummaryResultColumns[] = 
	{
	   "Compare Products", 
	   "Long Item Description", 
	   "Enterprise Product Identifier",
	   "Manufacturer",
	   "Manufacturer Catalog Number",
	   "National Drug Code (NDC)",
	   "Common Model",
	   "Product Status",
	   "Related Site Records",
	   "Site Equipment",
	   "Related Products",
	   "Equivalent Products",
	   "Preferred Product"
	};
	
	protected String expectedProductDetailLabels[] = 
	{
			"Manufacturer:", 
			"Manufacturer Catalog Number:",
			"HCPCS Status:",
			"Product Type:",
			"Product Commodity:",
			"Product Status:",
			"Commodity Type:",
			"Packaging Description:",
			"Trademark/Brand Names:",
			"Properties:",
			"Fragrance:",
			"Volume:",
			"Weight:"
	};
	
	protected String expectedExpandedProductDetailLabels[] = 
	{
		"Manufacturer:", 
		"Manufacturer Catalog Number:",
		"HCPCS Status:",
		"Product Type:",
		"Product Segment:",
		"Product Family:",
		"Product Class:",
		"Product Commodity:",
		"Product (UNSPSC) Code:",
		"Product Status:",
		"Commodity Type:",
		"Packaging Description:",
		"Product Composition:",
		"Trademark/Brand Names:",
		"Brand Type:",
		"Size/Shape:",
		"Properties:"
	};
	
	protected String expectedProductDetailLabels1[] = 
	{
		"Manufacturer:",
		"Manufacturer Catalog Number:",
		"HCPCS Status:", 
		"Product Type:", 
		"Product Segment:",
		"Product Family:",
		"Product Class:",
		"Product Commodity:",
		"Product (UNSPSC) Code:",
		"Product Status:",
		"Commodity Type:",
		"Packaging Description:",
		"Trademark/Brand Names:",
		"Size/Shape:",
		"Properties:",
		"Disposable:",
		"Dimensions:",
		"Latex Code:"
	};
	
	protected String expectedExpandedProductDetailLabels1[] = 
	{
		"Manufacturer:",
		"Manufacturer Catalog Number:",
		"HCPCS Status:",
		"Product Type:",
		"Product Commodity:",
		"Product Status:",
		"Commodity Type:",
		"Packaging Description:",
		"Trademark/Brand Names:",
		"Size/Shape:",
		"Properties:",
		"Disposable:",
		"Dimensions:",
		"Latex Code:"
	};
	
	
	
	/**************************** END ****************************/
	
	@BeforeClass
	public static void setUp() 
	{
		homepage.setUpEnv();
	}
	
	@Test
	public void testChromeSelenium() throws InterruptedException 
	{	
		 // Step 1 - 3 : Launch url and login to the logicole
		 homepage.startAppliaction(EnvironmentType.test_env);
		 homepage.selectUserProfile(userProfile);
		 homepage.selectABiSearch();
		 
		 // Step 4 : Click the Open/Close side panel
		 abisearchpage.expandSidePanel();
		 
		 // Step 5 : Select Dental or another product line category on the list
		 abisearchpage.SelectCategoryOption("Product Line", "Dental");
		 
		 // Step 5 - Expected  : The ABi search summary results display for the product line selected
		 abisearchpage.checkSummaryResultColumns(expectedSummaryResultColumns);
		 
		 // Step 6 : Click on product identifier to view prod details
		 abisearchpage.viewProductDetails(productIdentifier);
		 
		 // Step 7 : verify product identifier displayed accordingly
		 abisearchpage.verifyproductIdentifierInProductDetailsPage(productIdentifier);
		 
		 // Step 8 : Verify the following items display on the Product Details screen:
		 abisearchpage.verifyProductDetailLabels(expectedProductDetailLabels);
		 
		 // Step 9 : Click on + icon
		 abisearchpage.expandProductDetailLabel();
		 
		 // Step 10 : The commodity details listed display.
		 abisearchpage.verifyProductDetailLabels(expectedExpandedProductDetailLabels);
		 
		// Step 11 - Click back button and click on clearProduct line section
		 abisearchpage.goBackFromProductDetailsPage();
		 abisearchpage.ClearCategorySelections("Product Line");
		 
		//Step 12 :select another product line category on the list such as Laboratory
		abisearchpage.SelectCategoryOption("Product Line", "Laboratory");
		
		// Step 12 - Expected  : The ABi search summary results display for the product line selected
		abisearchpage.checkSummaryResultColumns(expectedSummaryResultColumns);
		
		// Step 13 : Click on product identifier to view prod details
		abisearchpage.viewProductDetails(productIdentifier1);
		
		// Step 13 : Expected - Verify product identifier displayed accordingly
		abisearchpage.verifyproductIdentifierInProductDetailsPage(productIdentifier1);
		
		// Step 13 : Expected - Verify the following items display on the Product Details screen:
		abisearchpage.verifyProductDetailLabels(expectedProductDetailLabels1);
		
		// Step 14 : Click on + icon
		abisearchpage.expandProductDetailLabel();
		
		// Step 14 : Expected - The commodity details listed display.
		abisearchpage.verifyProductDetailLabels(expectedExpandedProductDetailLabels1);
		
		//Step 15 - Click back button and click on clearProduct line section
		abisearchpage.goBackFromProductDetailsPage();
		abisearchpage.ClearCategorySelections("Product Line");
		
		 // Step 16 : logout and verify the output message
		 homepage.logout();
	}

	@AfterClass
	public static void cleanUp() 
	{
		homepage.cleanUpEnv();
	}

}